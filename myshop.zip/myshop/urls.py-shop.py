from django.conf.urls import url
from . import views


lpatterns = [
    url(r'^$', views.product_list, name='product_list'),
    url(r'^(?P<category_slug>[-\w]+)/$', views.product_list, name='product_list_by_category'),
    url(r'^(?P<id>\d+)/(?P<slug>[-\w]+)/$', views.product_detail, name='product_detail'),
]


##################################################################################


from django.conf.urls import url
from . import views


urlpatterns = [
    url(r'^process/$', views.payment_process, name='process'),
    url(r'^done/$', views.payment_done, name='done'),
    url(r'^canceled/$', views.payment_canceled, name='canceled'),
]



##########################################################################

from django.conf.urls import include, url
from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    url(r'^admin/', include(admin.site.urls)),
    url(r'^cart/', include('cart.urls', namespace='cart')),
    url(r'^orders/', include('orders.url', namespace='orders')),
    url(r'^paypal/', include('paypal.standard.ipn.urls')),
    url(r'^payment/', include('payment.urls', namespace='payment')),
    url(r'^',include('shop.urls', namespace='shop'))]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL,
                          document_root=settings.MEDIA_ROOT)



###########################Generaing pdf dynamically URL 4:35 CARPETA 2#########################3
from django.conf.urls import url
from . import views

urlpatterns =  [
    url(r'^create/$', views.order_create, name='order_create'),
    url(r'^admin/order/(?P<order_id>/d+)/$', views.admin_order_detail, name='admin_order_detail'),
    url(r'^admin/order/(?P<order_id>/d+)/pdf/$', views.admin_order_pdf, name='admin_order_pdf')
]