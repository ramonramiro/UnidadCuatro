from django.shortcuts import render ,redirec
from django.core.urlresolvers import reverse
from .models import orderItem
from .forms import orderCreateRorm
from .task import order_Created
from cart.cart import Cart


def order_create(request):
    cart - Cart(request)
    if request.method =='POST':
        form = OrderCreatedForm(request.POST)
        if form.is_valid():
            order = form.save()
            for item in cart:
                orderItem.objects.create(order=order,
                                         product=item['product'],
                                          price=item['proce'],
                                         quantity=item['quantity'])
                #clear the cart
                cart.clear()
                #Launch asynchranous task
                order_Created.dalay(order.id)
                #set the order in the session
                request.session['order_id'] = order.id
                #redirect to the payment
                return  redirec(reverse('payment:process'))
        else:
            form = OrderCreateForm()


