from django.shortcuts import get_object_or_404
from paypal.standard.models import ST_PP_COMPLETED
from paypal.standard.ipn.signals import valid_ipn_received
from orders.models import orders

def payment_notification(sender, **kwargs):
    ipn_obj = sender
    if ipn_obj.payment_status == ST_PP_COMPLETED:
        #payment was successful
        order = get_object_or_404(order, id=ipn_obj.invoice)

        #mark the order as paid
        order.paid = True
        order.save()

valid_ipn_received.connect(payment_notification)


