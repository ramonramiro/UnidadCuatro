from django.shortcuts import render, get_object_or_404
from .models import Category, Product
def product_list(request, category_slug=None):
    category = None
    categories = Category.objects.all()
    products = Product.objects.filter(available=True)
    if category_slug:
        category = get_object_or_404(Category, slug=category_slug)
        products = products.filter(category=category)
    return render(request, 'shop/product/list.html', {'category': category,
                                                      'categories': categories,
                                                      'products': products})

def product_detail(request, id, slug):
    product = get_object_or_404(Product, id=id, slug=slug, available=True)
    cart_product_form = CartAddProductForm()
    return render(request,
                  'shop/product/detail.html',
                  {'product': product,
                   'cart_product_form': cart_product_form})







from decimal import Decimal
from django.conf import settings
from django.core.urlresolver import reverse
from django.shortcuts import render, get_object_or_404
from paypal.standard.forms import PayPalPaymentsForm
from orders.models import Order
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def payment_done(request):
    return render(request, 'payment/done.html')

@csrf_exempt
def payment_cenceled(request):
    return render(request, 'payment/canceled.html')

def payment_process(request):
    order_id = request.session.get('order_id')
    order = get_object_or_404(Order, id=order_id)
    host = request.get_host()

    paypal_dict = {
        'business': settings.PAYPAL_RECETVER_EMAIL,
        'amount': '%.2f' % order.get_total_cost().quantize(Decimal('.01')),
        'item_name': 'order {}'.format(oreder.id),
        'invoice':str(order.id),
        'currency_code': 'USD',
        'notity_url':'http:// {}{}'.format(host, reverse('paypal-ipn')),
        'return_url': 'http:// {}{}'.format(host, reverse('payment:done')),
        'cancel_return': 'http:// {}{}'.format(host, reverse('payment:canceled')),
    }
    form = PayPalPaymentsForm(initial=paypal_dict)
    return render(request, 'payment/process.html', {'order': order,
                                                'form': form})


############careta 2 Generating PDF INVOICE DYNAMICAL  02:12
from django.shortcuts import render, get_object_or_404
from django.core.urlresolvers import reverse
from django.contrib.admin.vewws.decorators import staff_menber_required
from django.config import settings
from django.http import HttpResponse
from django.template.loader import render_to_string
from weasyprint
from .models import Order, OrderItem
from .forms import OrderCreated
from .task import order_created
from .cart.cart import Cart

def order_created(request):
    cart = Cart(request)
    if request.method == 'POST':
        form = OrderCreatedForm(request.POST)
        if form.is_valid():
            order = form.save()

            for item in cart:
                OrderItem.objects.create(order=order,
                                         product=item ['product'],
                                         price=item ['price'],
                                         quantity=item ['quantity'])
                #clear the cart
                cart.clear()
                #Launch asynchronous task
                order_created.delay(order.id)
                #ser the order in thd session
                request.session['order_id']= order.id
                #redirect to the payment
                return redirect(reverse('payment:process'))
            else:
                form = OrderCreatedForm()
            return render(request, 'orders/order/create.html', {'cart': cart,
                                                                'form': form})
    @staff_menber_required
    def admin_order_detail(request, order_id):
        order = get_object_or_404(Order, id=order_id)
        return  render(request, 'admin/orders/order/detail.html', {'order': order})

    @staff_menber_required
    def admin_order_pdf(request, order_id):
        order = get_object_or_404(Order, id=order_id)
        html = render_to_string('orders/order/pdf.html', {'order':order})
        response = HttpResponse(content_type='application/pdf')
        response ['Content-Disposition'] = 'filename="order_{}.pdf' .format(order.id)
        weasyprint.HTML(string=html).write_pdf(response,
                                               stylesheets= [weasyprint.CSS(settings.STATIC_ROOT + 'css/pdf.css')])
        return response



